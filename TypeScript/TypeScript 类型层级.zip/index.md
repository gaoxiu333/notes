# TypeScript 类型层级

* 类型层级指的是所有类型的兼容关系

* 类型兼容性

### 类型兼容性判断

```typescript
T extends D ? 1:2 // 如果T是D的子类型，返回1，否则返回2
```

![](assets/sbXodXeNZyk3M-AzmKNhcUoqa40adEDb4ezLAMyZjjc=.blob)

###
