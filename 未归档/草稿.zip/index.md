# 草稿

![](assets/nPgggTfNPtM37yNftfprpWEjbDOh_SkpCBepHTiAarw=.blob)

* 前端工具链

* 工作流

* 目标

  * 把脚手架编程库

  * 尽可能集成所有主流工具和最佳实践，让每个项目都能获得技术红利，把选择成本降到接近零

  * 尽可能把不属于应用项目本身、在不用项目之间共享的脚手架代码抽象到npm package里

* 约定大于配置





*

  *

